

<?php

    use Restserver\Libraries\REST_Controller;
    defined('BASEPATH') OR exit('No direct script access allowed');
    require APPPATH . 'libraries/REST_Controller.php';
    require APPPATH . 'libraries/Format.php';
    class Anime extends REST_Controller {
        function __construct()
        {
            parent::__construct();
            $this->load->model('Anime_model', 'anm');
        }
        // Get Data
        public function index_get() {
            $id_anime = $this->get('id_anime');
            // jika id tidak ada (tidak panggil) 
            if($id_anime === null) {
                // maka panggil semua data
                $anime = $this->anm->getAnime();
                // tapi jika id di panggil maka hanya id tersebut yang akan muncul pada data tersebut
            } else {
                $anime = $this->anm->getAnime($id_anime);
            }
            if($anime) {
                $this->response([
                    'status' => true,
                    'data' => $anime
                ], REST_Controller::HTTP_OK); // NOT_FOUND (404) being the HTTP response code
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
            
            }
        }
        // delete data
        public function index_delete() {
            $id_anime = $this->delete('id_anime');
            if($id_anime === null) {
                $this->response([
                    'status' => false,
                    'message' => 'provide an id'
                ], REST_Controller::HTTP_BAD_REQUEST); 
            } else {
                if($this->anm->deleteAnime($id_anime) > 0) {
                    // Ok
                    $this->response([
                        'status' => true,
                        'id_anime' => $id_anime,
                        'message' => 'deleted success'
                    ], REST_Controller::HTTP_NO_CONTENT);
                } else {
                    // id not found
                    $this->response([
                        'status' => false,
                        'message' => 'id not found'
                    ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
                
                }
            }
        }
        // post data
        public function index_post() {
            $data = [
                'id_anime' => $this->post('id_anime'),
                'id_episode_anime' => $this->post('id_episode_anime'),
                'title_anime' => $this->post('title_anime'),
                'desc_anime' => $this->post('desc_anime'),

                'id_banner_anime' => $this->post('id_banner_anime'),
                'link_anime' => $this->post('link_anime'),
                'id_series_anime' => $this->post('id_series_anime'),
                'created_time' => $this->post('created_time'),
                'updated_time' => $this->post('updated_time'),                
                'updated_by' => $this->post('updated_by')
            ];
            if ($this->anm->createAnime($data) > null) {
                $this->response([
                    'status' => true,
                    'message' => 'new Anime has been created'
                ], REST_Controller::HTTP_CREATED);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'failed create data'
                ], REST_Controller::HTTP_NOT_FOUND);
            }
        }
        // update data
        public function index_put() {
            $id_anime = $this->put('id_anime');
            $data = [
                'id_anime' => $this->put('id_anime'),
                'id_episode_anime' => $this->put('id_episode_anime'),
                'title_anime' => $this->put('title_anime'),
                'desc_anime' => $this->put('desc_anime'),

                'id_banner_anime' => $this->put('id_banner_anime'),
                'link_anime' => $this->put('link_anime'),
                'id_series_anime' => $this->put('id_series_anime'),
                'created_time' => $this->put('created_time'),
                'updated_time' => $this->put('updated_time'),                
                'updated_by' => $this->put('updated_by')
            ];
            
            if ($this->anm->updateAnime($data, $id_anime) > null) {
                $this->response([
                    'status' => true,
                    'message' => 'update Anime has been updated'
                ], REST_Controller::HTTP_NO_CONTENT);
            } else {
                $this->response([
                    'status' => false,
                    'message' => 'failed to update data'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }
?>
