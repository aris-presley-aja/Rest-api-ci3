<?php
    class Mahasiswa_model extends CI_model {
        public function getAnime($id_anime = null) {
            if($id_anime === null) {
                return $this->db->get('test_api')->result_array(); 
            } else {
                return $this->db->get_where('anime', ['id_anime' => $id_anime])->result_array();

            }
        }

        public function deleteAnime($id_anime) {
            $this->db->delete('anime', ['id_anime' => $id_anime]);
            return $this->db->affected_rows();
        }

        public function createAnime($data) {
            $this->db->insert('anime', $data);
            return $this->db->affected_rows();
        } 

        public function updateAnime($data, $id_anime) {
            $this->db->update('anime', $data, ['id_anime' => $id_anime]);
            return $this->db->affected_rows();
        }
    }
?>