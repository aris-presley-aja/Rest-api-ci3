-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 26, 2020 at 05:49 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_api`
--

-- --------------------------------------------------------

--
-- Table structure for table `anime`
--

CREATE TABLE `anime` (
  `id_anime` int(11) NOT NULL,
  `id_episode_anime` int(11) NOT NULL,
  `title_anime` varchar(100) NOT NULL,
  `desc_anime` text NOT NULL,
  `id_banner_anime` varchar(256) NOT NULL,
  `link_anime` text NOT NULL,
  `id_series_anime` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 : Active , 2 : Deleted',
  `created_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) NOT NULL,
  `updated_time` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `anime`
--

INSERT INTO `anime` (`id_anime`, `id_episode_anime`, `title_anime`, `desc_anime`, `id_banner_anime`, `link_anime`, `id_series_anime`, `status`, `created_time`, `created_by`, `updated_time`, `updated_by`) VALUES
(0, 0, '', '', '', '', 0, 1, '2020-07-26 11:07:22', 0, NULL, NULL),
(1, 0, 'Ep. 0 Prologue', 'Rin Tohsaka wakes up after having a dream about her last moment with her father Tokiomi Tohsaka. She arrives early to school, only to realize that the clocks at her home were set forward by an hour. She meets with other people at the school who arrived early, including Ayako Mitsuzuri, the captain of the archery club; Sakura Mat?, a new member of the archery club; Shinji Mat?, Sakura\'s older brother; Taiga Fujimura, one of the schoolteachers; Issei Ryuudou, the student council president; and Shirou Emiya, a boy fixing a heater for Issei. After school in preparation for the Fifth Holy Grail War, Rin performs a summoning ritual at home and summons the Servant Archer, who is initially dissatisfied with Rin. An irritated Rin then wastes one of her Command Seals and orders Archer into absolute obedience. While the order is worded vaguely and therefore seemingly pointless, Archer commends Rin for her skill as a mage. Archer has no memories of who he is after he was summoned, much to Rin\'s displeasure. The next day, Rin skips school and shows Archer around the city, revealing to him that she has no wish for the Holy Grail, only a desire to win. The following day, Rin senses a magical barrier being set up at school. As night falls, Rin attempts to destroy the barrier, but is then confronted by the Servant Lancer, who engages Archer in a sword fight. As they battle, Archer correctly deduces the true identity of Lancer as being the ancient Irish hero Cú Chulainn. The battle is witnessed by a student, whom Lancer pursues and mortally wounds before fleeing. Finding the student\'s body, Rin identifies him as Shirou and decides to use magic to revive him. After leaving, Rin and Archer realize that Lancer\'s Master will sense that Shirou has survived and have Lancer finish the job. As Rin and Archer head over to the suburbs, they are attacked by the Servant Saber.', 'bannerAnime0.png', 'https://www.youtube.com', 1, 1, '2019-09-27 09:14:08', 1, '2019-09-27 09:16:20', 1),
(2, 1, 'Ep 1. A Winter Day, A Fateful Night', 'Shirou is woken up his close friend Sakura. After having an interesting breakfast with Sakura and his legal guardian Taiga, Shirou goes to school and fixes a heater for Issei, which is briefly observed by Rin. Issei remarks that Shirou never hesitates in helping people in need and warns him that he may be taken advantage of by inconsiderate people like Shinji. While walking home from school, he encounters Illyasviel \"Illya\" von Einzbern, who warns him to summon a Servant soon before vanishing. The next day, while helping Sakura with the dishes, Shirou notices a bruise on her hand and assumes that Shinji is beating her. At school, he learns from Ayako that Shinji has recently been acting more aggressively. He is also informed by other female students of the murders of a family of four. While visiting the crime scene, Shirou recalls the time that he was rescued by Kiritsugu Emiya in the aftermath of a devastating fire that occurred ten years ago, later being adopted by him and learning that he is a mage. Shirou notes how he had devoted his life to Kiritsugu\'s ideals of becoming a hero of justice. The following day, Shirou stays late at school and confronts Shinji about Sakura\'s injury, but Shinji denies any involvement before asking Shirou to clean the school\'s archery dojo, which he decides to do. After finishing, Shirou witnesses the fight between Archer and Lancer, the latter of whom notices him. Running inside the school, Shirou is suddenly cornered by Lancer, who stabs him in the heart using a red spear-like Noble Phantasm, Gáe Bolg, and flees. Shirou nearly dies from his wound, but is revived by Rin, who quickly leaves before he can recognize her. Returning home, Shirou is attacked by Lancer again, being forced to escape into the backyard shed. There, he accidentally summons Saber, who wards off Lancer after a brief battle. After identifying Shirou as her Master, Saber engages Archer in a sword fight, but Shirou uses one of his Command Seals to stop her before she injures Archer. Shirou is then calmly greeted by Rin.', 'bannerAnime1.png', 'https://www.youtube.com', 1, 1, '2019-09-27 09:15:05', 1, '2019-09-27 09:16:24', 1),
(999, 99, 'aris priyanto', 'adalah anime yang dibuat oleh si anime', '986986986', 'yustup.com', 1, 1, '2019-09-27 09:16:20', 0, '2019-09-27 09:16:20', 1),
(9991, 99, 'aris aja priyanto kan', 'adalah anime yang dibuat oleh si anime', '986986986', 'yustuper.com', 1, 1, '2019-09-27 09:16:20', 0, '2019-09-27 09:16:20', 1);

-- --------------------------------------------------------

--
-- Table structure for table `series_movie`
--

CREATE TABLE `series_movie` (
  `id_series_movie` int(11) NOT NULL,
  `title_series_movie` varchar(100) NOT NULL,
  `desc_series_movie` text NOT NULL,
  `id_banner_series_movie` varchar(256) NOT NULL,
  `id_poster_series_movie` varchar(256) NOT NULL,
  `show_title_banner_series_movie` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 : Show , 0 : Invisible',
  `show_title_poster_series_movie` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1 : Show , 0 : Invisible',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 : Active , 2 : Deleted',
  `created_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) NOT NULL,
  `updated_time` timestamp NULL DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `series_movie`
--

INSERT INTO `series_movie` (`id_series_movie`, `title_series_movie`, `desc_series_movie`, `id_banner_series_movie`, `id_poster_series_movie`, `show_title_banner_series_movie`, `show_title_poster_series_movie`, `status`, `created_time`, `created_by`, `updated_time`, `updated_by`) VALUES
(0, 'kereta pagi ke Brebes ', 'komedi aksi', 'bannerSeriesMovie100.jpg', 'posterSeriesMovie1011.jpg', 1, 1, 1, '2019-09-26 03:39:59', 1, '2019-09-26 03:49:05', 1),
(3, 'Avengers End Game', 'This is Description End Game', 'bannerSeriesMovie0.jpg', 'posterSeriesMovie0.jpg', 1, 1, 2, '2019-09-26 03:39:05', 1, '2019-09-26 06:48:27', 1),
(4, 'Avengers : End Game', 'Adrift in space with no food or water, Tony Stark sends a message to Pepper Potts as his oxygen supply starts to dwindle. Meanwhile, the remaining Avengers -- Thor, Black Widow, Captain America and Bruce Banner -- must figure out a way to bring back their vanquished allies for an epic showdown with Thanos -- the evil demigod who decimated the planet and the universe.', 'bannerSeriesMovie1.jpg', 'posterSeriesMovie1.jpg', 0, 0, 1, '2019-09-26 06:51:30', 1, '2019-09-26 08:36:43', 1),
(5, 'Avengers : Infinity War', 'Iron Man, Thor, the Hulk and the rest of the Avengers unite to battle their most powerful enemy yet -- the evil Thanos. On a mission to collect all six Infinity Stones, Thanos plans to use the artifacts to inflict his twisted will on reality. The fate of the planet and existence itself has never been more uncertain as everything the Avengers have fought for has led up to this moment.', 'bannerSeriesMovie21.jpg', 'posterSeriesMovie21.jpg', 0, 0, 2, '2019-09-26 08:28:38', 1, '2019-09-26 08:28:56', 1),
(6, 'Avengers : Infinity War', 'Iron Man, Thor, the Hulk and the rest of the Avengers unite to battle their most powerful enemy yet -- the evil Thanos. On a mission to collect all six Infinity Stones, Thanos plans to use the artifacts to inflict his twisted will on reality. The fate of the planet and existence itself has never been more uncertain as everything the Avengers have fought for has led up to this moment.', 'bannerSeriesMovie3.jpg', 'posterSeriesMovie3.jpg', 0, 0, 1, '2019-09-26 08:29:16', 1, '2019-09-26 08:36:37', 1),
(7, 'Doctor Strange', 'Dr. Stephen Strange\'s (Benedict Cumberbatch) life changes after a car accident robs him of the use of his hands. When traditional medicine fails him, he looks for healing, and hope, in a mysterious enclave. He quickly learns that the enclave is at the front line of a battle against unseen dark forces bent on destroying reality. Before long, Strange is forced to choose between his life of fortune and status or leave it all behind to defend the world as the most powerful sorcerer in existence.', 'bannerSeriesMovie4.jpg', 'posterSeriesMovie4.jpg', 0, 0, 1, '2019-09-27 03:07:10', 1, NULL, NULL),
(8, 'Captain America : Civil War', 'Political pressure mounts to install a system of accountability when the actions of the Avengers lead to collateral damage. The new status quo deeply divides members of the team. Captain America (Chris Evans) believes superheroes should remain free to defend humanity without government interference. Iron Man (Robert Downey Jr.) sharply disagrees and supports oversight. As the debate escalates into an all-out feud, Black Widow (Scarlett Johansson) and Hawkeye (Jeremy Renner) must pick a side.', 'bannerSeriesMovie5.jpg', 'posterSeriesMovie5.jpg', 1, 0, 1, '2019-09-27 03:08:53', 1, NULL, NULL),
(9, 'kereta ke Brazillia barat daya', 'komedi romantis', 'bannerSeriesMovie100.jpg', 'posterSeriesMovie1011.jpg', 1, 1, 1, '2019-09-26 03:39:59', 1, '2019-09-26 03:49:05', 1),
(39, 'dibawah lindungan abah', 'komedi', 'bannerSeriesMovie10.jpg', 'posterSeriesMovie10.jpg', 1, 1, 1, '2019-09-26 03:39:59', 1, '2019-09-26 03:39:05', 1),
(91, 'kereta pagi ke Brebes Timur', 'komedi romantis', 'bannerSeriesMovie100.jpg', 'posterSeriesMovie1011.jpg', 1, 1, 1, '2019-09-26 03:39:59', 1, '2019-09-26 03:49:05', 1),
(99, 'kereta ke Brazillia', 'komedi', 'bannerSeriesMovie10.jpg', 'posterSeriesMovie10.jpg', 1, 1, 1, '2019-09-26 03:39:59', 1, '2019-09-26 03:39:05', 1),
(100, 'kereta ke Brazillia barat daya saja', 'komedi romantis', 'bannerSeriesMovie100.jpg', 'posterSeriesMovie1011.jpg', 1, 1, 1, '2019-09-26 03:39:59', 1, '2019-09-26 03:49:05', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anime`
--
ALTER TABLE `anime`
  ADD PRIMARY KEY (`id_anime`);

--
-- Indexes for table `series_movie`
--
ALTER TABLE `series_movie`
  ADD PRIMARY KEY (`id_series_movie`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anime`
--
ALTER TABLE `anime`
  MODIFY `id_anime` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9992;

--
-- AUTO_INCREMENT for table `series_movie`
--
ALTER TABLE `series_movie`
  MODIFY `id_series_movie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
